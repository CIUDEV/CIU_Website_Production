# Prayer Times Page (`/Services/prayer-times`)

## Hero

**Label:** Daily Salah  
**Heading:** Prayer Times  
**Intro:** View daily, weekly, monthly, and yearly iqamah times for CIU in Mississauga based on the published CIU prayer calendar.

---

## Today's schedule

**Label:** Schedule  
**Heading:** Prayer Times  
**Location:** Mississauga, Ontario  
**Note:** Maghrib iqamah follows sunset for each date.

*(Actual daily prayer times are loaded from the CIU yearly calendar data — not listed in this document. Review the live page or calendar file for specific times.)*

---

## Jumu'ah (Friday Prayer)

**Label:** Jumu'ah  
**Heading:** Friday Prayer  
**Intro:** CIU holds one Jumu'ah each Friday at the masjid.

**Schedule (year-round):**
- **Khutbah:** 1:45 PM
- **Salah:** 2:05 PM

---

## Important Notes

**Label:** Important Notes  
**Heading:** Schedule Information

### Jumu'ah Prayer
One Jumu'ah is held each Friday. Khutbah begins at 1:45 PM and Salah is at 2:05 PM year-round.

### Iqamah Calendar
Fajr, Dhuhr, Asr, and Isha follow the CIU yearly iqamah calendar. Maghrib follows sunset for Mississauga.

### Seasonal Adjustments
Times change throughout the year by date range. Use the monthly calendar to browse any month day by day.

### Daylight Saving Time
Schedule shifts are applied around daylight saving changes in March and November, as shown in the yearly calendar.

---

## CTA

**Heading:** Questions About Prayer Times?  
**Text:** Contact CIU if you need help confirming Jumu'ah, holiday schedules, or community prayer arrangements.  
**Buttons:** Contact CIU · Visit Our Services

---

## Home page widget (same content, abbreviated)

**Heading:** Today's Prayer Times  
**Location:** Mississauga, Ontario  
**Note:** Iqamah times from the CIU yearly calendar. Maghrib is calculated at sunset.  
**Link:** View Full Schedule
